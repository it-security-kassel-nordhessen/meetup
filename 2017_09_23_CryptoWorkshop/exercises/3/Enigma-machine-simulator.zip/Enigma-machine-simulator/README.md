https://en.wikipedia.org/wiki/Cyclometer 
Einstellungen und Kryptotext gegen Wiki-Eintrag vergleichen
